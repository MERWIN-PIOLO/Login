package com.loginactivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find views by their IDs
        val usernameEditText: EditText = findViewById(R.id.username)
        val passwordEditText: EditText = findViewById(R.id.password)
        val loginButton: Button = findViewById(R.id.login_button)
        val loginConfirmationTextView: TextView = findViewById(R.id.login_code_confirmation)
        val loginCodeTextView: TextView = findViewById(R.id.login_code)

        // Set an OnClickListener for the login button
        loginButton.setOnClickListener {
            // Get the text from the EditText fields
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (username.equals("MERWIN", ignoreCase = true) && password == "1234") {
                // If login is successful, display a welcome message and a login code
                loginConfirmationTextView.text = getString(R.string.login_code_confirmation, username)
            } else {
                // If login fails, display an error message
                loginConfirmationTextView.text = getString(R.string.login_failed)
                loginCodeTextView.text = "" // Clear the login code
            }
        }
    }
}